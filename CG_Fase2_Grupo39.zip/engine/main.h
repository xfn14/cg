#ifndef _MAIN_
#define _MAIN_

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#define _USE_MATH_DEFINES

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <iostream>

#include "world.h"
#include "../utils/model.h"

using namespace std;

#endif