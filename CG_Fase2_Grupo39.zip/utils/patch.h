#ifndef _BEZIER_PATCH_
#define _BEZIER_PATCH_

#include <iostream>
#include <vector>

#include "point.h"

using namespace std;

class Patch {
    private:
        vector<Point> controlPoints;

    public:
        Patch();
        void addPoint(Point);
        vector<Point> getPoints();
};

#endif